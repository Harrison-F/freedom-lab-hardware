"""Local Blender concept visualization. Run with Blender --background --factory-startup --python this_file.
All dimensions in mm. See evidence.json: shell design and internal blocks are illustrative,
not fitted CAD, wiring, or a vendor teardown. Wi-Fi v1 only; no LTE hardware required.
"""
import bpy, math, json, pathlib, sys, os
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
OUT=pathlib.Path(__file__).resolve().parent
bpy.context.preferences.filepaths.save_version=0
PARTS=[]
CONFIGS=[
 dict(id='compact154',title='Pocket e-paper',subtitle='Waveshare 1.54 · SKU32298',w=39.8,h=53.0,d=16.9,sw=27.8,sh=27.8,sy=5.5,r=4.5,color=(.78,.76,.68,1),accent=(.76,.21,.065,1),basis='39.8 × 53.0 × 16.9 mm family case reference',note='Older-revision family drawing; current V2 fit unverified.'),
 dict(id='reader397',title='Quiet reader',subtitle='Waveshare 3.97 · SKU33552',w=66,h=116,d=18,sw=51.84,sh=86.4,sy=5.5,r=5,color=(.22,.34,.29,1),accent=(.80,.43,.13,1),basis='60.0 × 99.5 mm board · 51.84 × 86.4 mm active area',note='Outer shell 66 × 116 × 18 mm is an illustrative design target, not a measured fit.'),
 dict(id='sticks3',title='Stick voice bridge',subtitle='M5Stack StickS3 · K150 · provisional',w=24,h=48,d=15,sw=14.1,sh=25.0,sy=5.5,r=2.5,color=(.055,.070,.075,1),accent=(.025,.34,.85,1),basis='24.0 × 48.0 × 15.0 mm vendor case reference',note='LCD, not e-paper. Exact physical hardware revision remains unverified.')]

def mat(name,color,metal=0,rough=.42):
 m=bpy.data.materials.new(name);m.diffuse_color=color;m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=color;p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 return m

def bevel(o,width=.4):
 m=o.modifiers.new('Soft molded edges','BEVEL');m.width=width;m.segments=3
 o.modifiers.new('Weighted surface normals','WEIGHTED_NORMAL')

def box(name,dims,loc,material,r=.3):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=dims;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if r:bevel(o,r)
 o.data.materials.append(material);return o

def rounded(w,h,r,cx=0,cy=0,n=12):
 pts=[]
 for x,y,a in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
  for i in range(n):
   t=math.radians(a+i*90/(n-1));pts.append((cx+x+r*math.cos(t),cy+y+r*math.sin(t)))
 return pts

def ring(name,w,h,r,iw,ih,ir,z,depth,material,ix=0,iy=0):
 a=rounded(w,h,r);b=rounded(iw,ih,ir,ix,iy);N=len(a)
 verts=[(x,y,zz) for zz in [z,z+depth] for loop in [a,b] for x,y in loop];faces=[]
 for i in range(N):
  j=(i+1)%N
  faces.extend([(i,j,2*N+j,2*N+i),(N+j,N+i,3*N+i,3*N+j),(2*N+i,2*N+j,3*N+j,3*N+i),(j,i,N+i,N+j)])
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);o.data.materials.append(material);bevel(o,.18);return o

def pill(name,w,h,d,x,y,z,material,r=1):
 pts=rounded(w,h,min(r,w/2-.01,h/2-.01));N=len(pts);verts=[(px+x,py+y,zz) for zz in [z-d/2,z+d/2] for px,py in pts]
 faces=[tuple(reversed(range(N))),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N) for i in range(N)]
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.data.materials.append(material);bevel(o,min(.18,d/5));return o

def cyl(name,r,depth,loc,material):
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=r,depth=depth,location=loc);o=bpy.context.object;o.name=name;o.data.materials.append(material);bevel(o,.12);return o

def text(name,body,size,loc,material):
 cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.align_x='CENTER';cu.align_y='CENTER';cu.size=size;cu.extrude=0
 ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);ob.location=loc;ob.data.materials.append(material);return ob

def group(name,fn):
 old=set(bpy.data.objects);fn();obs=set(bpy.data.objects)-old
 for o in obs:o['concept_component']=name
 PARTS.append((name,list(obs)))

def point(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,loc,power,size,color,target):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=color;point(o,target)

def build(c,exploded):
 global PARTS
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);PARTS=[]
 w,h,d=c['w'],c['h'],c['d'];sw,sh,sy=c['sw'],c['sh'],c['sy'];stick=c['id']=='sticks3';large=c['id']=='reader397'
 shell=mat('Fine matte polymer',c['color']);dark=mat('Aperture black',(.008,.012,.014,1),rough=.8);gasket=mat('Silicone gasket',(.035,.043,.045,1),rough=.9)
 accent=mat('Tactile PTT',c['accent']);paper=mat('E-paper surface' if not stick else 'LCD face',(.73,.75,.68,1) if not stick else (.025,.045,.053,1),rough=.65)
 ink=mat('UI ink',(.022,.037,.04,1) if not stick else (.67,.86,.78,1),rough=.75)
 pcbmat=mat('Illustrative PCB solder mask',(.018,.17,.13,1),rough=.6);silver=mat('Metal shield',(.52,.56,.58,1),.8,.28);foil=mat('Unspecified battery pouch',(.47,.50,.51,1),.6,.36);gold=mat('Contact finish',(.63,.40,.12,1),.75,.3)
 rear_depth=d*.40; front_z=d-2.2;pcb_z=d*.62;screen_z=d-1.0 if stick else d-3.0
 def rear():
  pill('Rear shell base',w,h,1.3,0,0,.65,shell,c['r'])
  ring('Rear shell rim',w,h,c['r'],w-2.8,h-2.8,max(.7,c['r']-1.4),1.3,rear_depth-1.3,shell)
  for x in [-w/2+3.4,w/2-3.4]:
   for y in [-h/2+3.4,h/2-3.4]:
    cyl('Screw boss',1.4,rear_depth-1.7,(x,y,(rear_depth+1.7)/2),shell);cyl('Thread insert',.68,.7,(x,y,rear_depth+.1),gold)
 group('Rear shell · conceptual',rear)
 def battery():
  bw=w*.62;bh=h*.39;by=-h*.06
  pill('Battery placeholder — envelope unverified',bw,bh,2.8,0,by,4.0,foil,1)
  box('Pouch seam A',(bw+.6,1,.45),(0,by+bh/2,4.0),silver)
  box('Pouch seam B',(bw+.6,1,.45),(0,by-bh/2,4.0),silver)
  box('Insulating tape',(bw*.5,3,.4),(0,by+bh*.3,5.55),gasket)
  # No capacity or wiring is invented. Placeholder volume only.
 group('Battery · unspecified envelope',battery)
 def board():
  bw,bh=(60,99.5) if large else (w-5,h-5)
  pill('Controller PCB — approximate component layout',bw,bh,1.2,0,0,pcb_z,pcbmat,1.5)
  box('RF shield — illustrative',(bw*.40,bh*.24,1.5),(-bw*.12,bh*.20,pcb_z+1.35),silver)
  text('PCB legend','ESP32-S3',min(w*.055,3),(0,-bh*.04,pcb_z+.66),paper)
  for i in range(7):
   box('Passive component',(1.4,2.2,.65),(bw*.34,-bh*.15+i*2.8,pcb_z+.96),gasket,.08)
  for i in range(5):
   box('Antenna illustration',(1,1.1,.12),(-bw*.33+i*1.5,bh*.39,pcb_z+.68),gold,.03)
  for x in [-bw*.30,bw*.30]:
   for y in [-bh*.38,bh*.38]:cyl('Mount point',.8,.15,(x,y,pcb_z+.68),gold)
  # Audio packaged as an indicative rectangular cavity, not a verified part model.
  speaker_y=-h*.34 if not stick else h*.34
  pill('Speaker cavity — approximate',min(w*.44,24),min(h*.11,11),2.8,0,speaker_y,pcb_z+2.1,gasket,1.5)
  pill('Speaker diaphragm',min(w*.35,20),min(h*.065,7),.3,0,speaker_y,pcb_z+3.7,dark,1)
  box('MEMS microphone — illustrative',(2.5,2.5,1.2),(-w*.30,-h*.31,pcb_z+1.2),silver)
  cyl('Mic port',.36,.1,(-w*.30,-h*.31,pcb_z+1.85),dark)
  # Generic connector representation; exact placement and electrical routing unverified.
  pill('USB-C outer',8.5,3.0,2.3,0,-h/2+2,pcb_z+.8,silver,1)
  pill('USB-C opening',6.5,1.4,.3,0,-h/2+2,pcb_z+2,dark,.5)
 group('Wi-Fi + audio PCB · layout approximate',board)
 def display():
  pill('Display backing',sw+2.2,sh+2.2,.8,0,sy,screen_z-.5,gasket,.8)
  pill('Visible active display',sw,sh,.45,0,sy,screen_z+.14,paper,.25)
  box('Display flex — indicative',(sw*.2,4,.15),(sw*.30,sy-sh/2-1.4,screen_z-.7),gold,.05)
  text('Sparse ready UI','Ready',min(sw*.17,6),(0,sy+sh*.10,screen_z+.385),ink)
  text('Hold hint','Hold to talk',min(sw*.083,3),(0,sy-sh*.12,screen_z+.385),ink)
  # restrained status dot, rather than fake busy panels
  cyl('Status dot',sw*.025,.03,(0,sy+sh*.32,screen_z+.39),ink)
 group('Display · sourced active proportions',display)
 def front():
  ring('Front shell side skirt',w,h,c['r'],w-2.8,h-2.8,max(.7,c['r']-1.4),rear_depth+.18,front_z-rear_depth-.18,shell)
  ring('Front shell with real display aperture',w,h,c['r'],sw+.35,sh+.35,.5,front_z,2.2,shell,iy=sy)
  # Seam is represented by the lower shell rim and narrow shadow line.
  by=-h*.345 if not large else -h*.426
  bw=min(w*.44,22);bh=3.0 if stick else (5 if large else 5.1)
  pill('PTT inset surround',bw+1.1,bh+1.1,.25,0,by,d+.02,gasket,1.7)
  pill('Physical hold-to-talk button',bw,bh,1.2,0,by,d+.6,accent,1.4)
  text('PTT button legend','PTT',min(w*.07,2.4),(0,by,d+1.22),dark)
  # Dark aperture insets are visual proxies, not machined acoustic hole specifications.
  fy=-h*.443 if not large else -h*.485
  if not stick:
   for i in range(7):
    cyl('Speaker perforation',.47 if not large else .65,.15,((i-3)*1.85,fy,d+.02),dark)
   cyl('Microphone aperture',.52,.12,(-w*.34,by,d+.025),dark)
  else:
   # StickS3 source has the speaker outlet at the top end, not below its PTT.
   for i in range(3):
    box('Top speaker slot',(.9,.18,3.0),((i-1)*2.0,h/2+.06,d-4),dark,.18)
   cyl('Front status aperture',.35,.12,(-w*.34,by,d+.025),dark)
  # Concept USB-C exterior inset, not a certified connector cutout.
  box('USB-C rim',(9.1,.25,3.3),(0,-h/2-.04,d*.60),silver,.6)
  box('USB-C dark opening',(7.1,.18,2.0),(0,-h/2-.19,d*.60),dark,.55)
  box('USB-C tongue',(5.5,.20,.32),(0,-h/2-.30,d*.60),gasket,.12)
  if large:
   # Rotary-control concept placement; protrusion/shaft dimensions remain unknown.
   knob=cyl('Retained rotary control · envelope approximate',3.7,2.5,(w/2+1.0,h*.30,d-5),gasket);knob.rotation_euler.y=math.pi/2
   for i in range(16):
    a=i*math.tau/16
    box('Knob knurl',(.35,.45,.75),(w/2+2.3,h*.30+3.5*math.cos(a),d-5+3.5*math.sin(a)),silver,.1)
 group('Front shell + physical PTT · concept',front)
 # Finished assembly hides illustrative internals naturally under front and back.
 # In exploded render move entire named groups, preserving their exact component geometries.
 spread=h*1.10
 anchors=[]
 if exploded:
  for i,(name,objects) in enumerate(PARTS):
   delta=Vector((-(i-2)*w*.35,0,i*spread))
   for o in objects:o.location+=delta
   anchors.append((name,Vector((w*.52+delta.x,0,d+delta.z))))
 maxz=d+4*spread if exploded else d
 floor=mat('Warm studio background',(.78,.76,.70,1),rough=.8)
 box('Studio ground',(1600,1600,1),(0,0,-2),floor,.0)
 target=(0,0,maxz*.46 if exploded else d*.4)
 distance=max(h,w,maxz)
 bpy.ops.object.camera_add(location=(distance*.90,-distance*1.3,distance*1.75+(maxz*.35 if exploded else 0)))
 camera=bpy.context.object;camera.name='Editorial orthographic camera';point(camera,target);camera.data.type='ORTHO';camera.data.clip_start=.1;camera.data.clip_end=10000;camera.data.ortho_scale=(maxz*.98+h*.65) if exploded else h*1.45
 scene=bpy.context.scene;scene.camera=camera
 light('Large softbox',(-distance*1.5,-distance*.7,distance*2.8),distance**2*50,distance*1.8,(1,.93,.84),target)
 light('Cool edge strip',(distance*1.7,distance*.6,distance*2),distance**2*38,distance,(.77,.86,1),target)
 light('Front fill',(0,-distance*2,distance*.7),distance**2*12,distance*1.4,(1,1,1),target)
 scene.world.color=(.25,.25,.25)
 scene.render.engine=os.environ.get('VOICE_RENDER_ENGINE','BLENDER_EEVEE');scene.cycles.device='CPU';scene.cycles.samples=int(os.environ.get('VOICE_RENDER_SAMPLES','24'));scene.cycles.use_denoising=True
 if hasattr(scene,'eevee') and hasattr(scene.eevee,'taa_render_samples'):scene.eevee.taa_render_samples=32
 scene.render.threads_mode='FIXED';scene.render.threads=6
 scene.render.resolution_x=1200;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
 scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
 scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
 scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=.001
 scene['visual_status']='Concept visualization only. Internal geometry and new enclosure are approximate, NOT fit-tested.'
 scene['v1_scope']='Wi-Fi, microphone, physical PTT, speaker and battery; LTE optional later and excluded.'
 scene['source_basis']=c['basis'];scene['source_note']=c['note']
 for name,objects in PARTS:
  coll=bpy.data.collections.new(name);scene.collection.children.link(coll)
  for o in objects:
   for old in list(o.users_collection):old.objects.unlink(o)
   coll.objects.link(o)
 bpy.context.view_layer.update()
 metadata=dict(c);metadata['view']='exploded' if exploded else 'finished';metadata['anchors']=[]
 for name,p in anchors:
  q=world_to_camera_view(scene,camera,p);metadata['anchors'].append({'label':name,'pixel':[q.x*1200,(1-q.y)*1200]})
 stem=c['id']+'-'+metadata['view'];scene.render.filepath=str(OUT/(stem+'-raw.png'))
 bpy.ops.wm.save_as_mainfile(filepath=str(OUT/(stem+'.blend')))
 (OUT/(stem+'.json')).write_text(json.dumps(metadata,indent=2))
 print('RENDER_START',stem,flush=True);bpy.ops.render.render(write_still=True);print('RENDER_OK',stem,flush=True)

if __name__=='__main__':
 args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
 selected=[arg for arg in args if not arg.startswith('--')]
 for c in CONFIGS:
  if selected and c['id'] not in selected:continue
  for exploded in ((True,) if '--exploded-only' in args else (False,True)):build(c,exploded)
