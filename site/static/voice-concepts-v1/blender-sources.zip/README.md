# Voice hardware concept sources

Six editable Blender 5.2 scenes. All geometry is approximate except documented manufacturer references in evidence.json; no mechanical fit, battery, wiring or power validation.

Run `blender --background --factory-startup --python render_devices.py` to regenerate all six views with EEVEE. Append `-- compact154`, `-- reader397`, or `-- sticks3` for one device. The script writes files beside itself. Every scene includes five named conceptual component groups.

Finished and exploded views share the same components. Unit scale is millimeters; camera clipping is extended for larger exploded stacks. No plugins, account or paid image service required.
